package FullStack;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;

public class NewContact extends JFrame implements ActionListener {
    JTextField firstNameField, lastNameField, phoneField;
    JButton saveButton, backButton;

    public NewContact() {
        setTitle("Contact Book - New Contact");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        Font titleFont = new Font("Arial", Font.BOLD, 28);
        Font labelFont = new Font("Arial", Font.PLAIN, 22);
        Font fieldFont = new Font("Arial", Font.PLAIN, 20);
        Font buttonFont = new Font("Arial", Font.BOLD, 22);

        JLabel newContactLabel = new JLabel("New Contact");
        newContactLabel.setFont(titleFont);
        newContactLabel.setBounds(100, 50, 300, 40);
        add(newContactLabel);

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setFont(labelFont);
        firstNameLabel.setBounds(100, 120, 150, 30);
        add(firstNameLabel);

        firstNameField = new JTextField();
        firstNameField.setFont(fieldFont);
        firstNameField.setBounds(260, 120, 250, 30);
        add(firstNameField);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setFont(labelFont);
        lastNameLabel.setBounds(100, 170, 150, 30);
        add(lastNameLabel);

        lastNameField = new JTextField();
        lastNameField.setFont(fieldFont);
        lastNameField.setBounds(260, 170, 250, 30);
        add(lastNameField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(labelFont);
        phoneLabel.setBounds(100, 220, 150, 30);
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setFont(fieldFont);
        phoneField.setBounds(260, 220, 250, 30);
        add(phoneField);

        saveButton = new JButton("Save");
        saveButton.setFont(buttonFont);
        saveButton.setBounds(100, 280, 410, 40);
        saveButton.addActionListener(this);
        add(saveButton);

        backButton = new JButton("Back to Dashboard");
        backButton.setFont(new Font("Arial", Font.BOLD, 20));
        backButton.setBounds(100, 350, 250, 40);
        backButton.addActionListener(this);
        add(backButton);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == saveButton) {
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String phone = phoneField.getText().trim();

            if (firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields!", "Warning",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            try (FileWriter fw = new FileWriter("contact.txt", true)) {
                fw.write(firstName + " " + lastName + "," + phone + "\n");
                JOptionPane.showMessageDialog(this, "Contact saved successfully!", "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                firstNameField.setText("");
                lastNameField.setText("");
                phoneField.setText("");
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving contact!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == backButton) {
            dispose();
            new DashboardMain();
        }
    }
}
