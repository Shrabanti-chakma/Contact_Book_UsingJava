package FullStack;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class DeleteContact extends JFrame implements ActionListener {
    JTextField deleteField;
    JButton deleteButton, backButton;

    public DeleteContact() {
        setTitle("Contact Book - Delete Contact");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        Font titleFont = new Font("Arial", Font.BOLD, 28);
        Font labelFont = new Font("Arial", Font.PLAIN, 22);
        Font fieldFont = new Font("Arial", Font.PLAIN, 20);
        Font buttonFont = new Font("Arial", Font.BOLD, 22);

        JLabel deleteContactLabel = new JLabel("Delete Contact");
        deleteContactLabel.setFont(titleFont);
        deleteContactLabel.setBounds(100, 50, 300, 40);
        add(deleteContactLabel);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        nameLabel.setBounds(100, 120, 100, 30);
        add(nameLabel);

        deleteField = new JTextField();
        deleteField.setFont(fieldFont);
        deleteField.setBounds(220, 120, 250, 30);
        add(deleteField);

        deleteButton = new JButton("Delete");
        deleteButton.setFont(buttonFont);
        deleteButton.setBounds(100, 180, 370, 40);
        deleteButton.addActionListener(this);
        add(deleteButton);

        backButton = new JButton("Back to Dashboard");
        backButton.setFont(new Font("Arial", Font.BOLD, 20));
        backButton.setBounds(100, 350, 250, 40);
        backButton.addActionListener(this);
        add(backButton);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == deleteButton) {
            String nameToDelete = deleteField.getText().trim();

            if (nameToDelete.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a name to delete!", "Warning",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            File inputFile = new File("contact.txt");
            File tempFile = new File("temp.txt");

            boolean found = false;

            try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                 BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.toLowerCase().startsWith(nameToDelete.toLowerCase() + " ")) {
                        writer.write(line);
                        writer.newLine();
                    } else {
                        found = true;
                    }
                }

            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error reading or writing file.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (inputFile.delete()) {
                if (tempFile.renameTo(inputFile)) {
                    if (found) {
                        JOptionPane.showMessageDialog(this, "Contact deleted successfully!", "Success",
                                JOptionPane.INFORMATION_MESSAGE);
                        deleteField.setText("");
                    } else {
                        JOptionPane.showMessageDialog(this, "Contact not found.", "Info",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } else if (e.getSource() == backButton) {
            dispose();
            new DashboardMain();
        }
    }
}
