package FullStack;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;

public class AuthDashboard extends JFrame implements ActionListener {

    private JTextField nameField, cpassField, emailField, uNameField;
    private JPasswordField passField, upassField;
    private JButton signUpButton, signInButton;

    public AuthDashboard() {
        super("Contact Book");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        Font labelFont = new Font("Arial", Font.PLAIN, 22);
        Font fieldFont = new Font("Arial", Font.PLAIN, 20);
        Font buttonFont = new Font("Arial", Font.BOLD, 20);

        Color labelColor = new Color(25, 25, 112); // Midnight Blue
        Color fieldBg = Color.WHITE;
        Color fieldFg = Color.BLACK;

        JLabel nameLabel = new JLabel("Name");
        nameLabel.setFont(labelFont);
        nameLabel.setForeground(labelColor);
        nameLabel.setBounds(150, 150, 200, 35);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setFont(fieldFont);
        nameField.setBounds(370, 150, 250, 35);
        nameField.setBackground(fieldBg);
        nameField.setForeground(fieldFg);
        add(nameField);

        JLabel passJLabel = new JLabel("Password");
        passJLabel.setFont(labelFont);
        passJLabel.setForeground(labelColor);
        passJLabel.setBounds(150, 210, 200, 35);
        add(passJLabel);

        passField = new JPasswordField();
        passField.setFont(fieldFont);
        passField.setBounds(370, 210, 250, 35);
        passField.setBackground(fieldBg);
        passField.setForeground(fieldFg);
        add(passField);

        JLabel cpassJLabel = new JLabel("Confirm Password");
        cpassJLabel.setFont(labelFont);
        cpassJLabel.setForeground(labelColor);
        cpassJLabel.setBounds(150, 270, 200, 35);
        add(cpassJLabel);

        cpassField = new JTextField();
        cpassField.setFont(fieldFont);
        cpassField.setBounds(370, 270, 250, 35);
        cpassField.setBackground(fieldBg);
        cpassField.setForeground(fieldFg);
        add(cpassField);

        JLabel emailJLabel = new JLabel("Email");
        emailJLabel.setFont(labelFont);
        emailJLabel.setForeground(labelColor);
        emailJLabel.setBounds(150, 330, 200, 35);
        add(emailJLabel);

        emailField = new JTextField();
        emailField.setFont(fieldFont);
        emailField.setBounds(370, 330, 250, 35);
        emailField.setBackground(fieldBg);
        emailField.setForeground(fieldFg);
        add(emailField);

        signUpButton = new JButton("Sign Up");
        signUpButton.setFont(buttonFont);
        signUpButton.setBounds(150, 400, 470, 45);
        signUpButton.addActionListener(this);
        add(signUpButton);

        JLabel unameJLabel = new JLabel("Name");
        unameJLabel.setFont(labelFont);
        unameJLabel.setForeground(labelColor);
        unameJLabel.setBounds(850, 150, 200, 35);
        add(unameJLabel);

        uNameField = new JTextField();
        uNameField.setFont(fieldFont);
        uNameField.setBounds(1070, 150, 250, 35);
        uNameField.setBackground(fieldBg);
        uNameField.setForeground(fieldFg);
        add(uNameField);

        JLabel upassJLabel = new JLabel("Password");
        upassJLabel.setFont(labelFont);
        upassJLabel.setForeground(labelColor);
        upassJLabel.setBounds(850, 210, 200, 35);
        add(upassJLabel);

        upassField = new JPasswordField();
        upassField.setFont(fieldFont);
        upassField.setBounds(1070, 210, 250, 35);
        upassField.setBackground(fieldBg);
        upassField.setForeground(fieldFg);
        add(upassField);

        signInButton = new JButton("Sign In");
        signInButton.setFont(buttonFont);
        signInButton.setBounds(850, 280, 470, 45);
        signInButton.addActionListener(this);
        add(signInButton);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signUpButton) {
            String name = nameField.getText().trim();
            String password = new String(passField.getPassword());
            String confirmPassword = cpassField.getText().trim();

            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (FileWriter fw = new FileWriter("users.txt", true)) {
                fw.write(name + "," + password + "\n");
                JOptionPane.showMessageDialog(this, "Sign Up Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
                new DashboardMain();
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving user information.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } else if (e.getSource() == signInButton) {
            String inputName = uNameField.getText().trim();
            String inputPass = new String(upassField.getPassword());
            boolean authenticated = false;

            try (Scanner scanner = new Scanner(new File("users.txt"))) {
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    String[] parts = line.split(",");
                    if (parts.length == 2) {
                        String storedName = parts[0].trim();
                        String storedPass = parts[1].trim();
                        if (inputName.equals(storedName) && inputPass.equals(storedPass)) {
                            authenticated = true;
                            break;
                        }
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error reading user data!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (authenticated) {
                JOptionPane.showMessageDialog(this, "Sign In Successful!", "Welcome", JOptionPane.INFORMATION_MESSAGE);
                dispose();
                new DashboardMain();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.", "Authentication Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

   
}
