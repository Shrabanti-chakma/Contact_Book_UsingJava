package FullStack;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class DashboardMain extends JFrame implements ActionListener {
    JButton btnUpdate, btnCreate, btnDelete;
    JTable table;
    DefaultTableModel tableModel;

    public DashboardMain() {
        setTitle("Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        Font labelFont = new Font("Arial", Font.BOLD, 26);
        Font tableFont = new Font("Arial", Font.PLAIN, 20);
        Font buttonFont = new Font("Arial", Font.BOLD, 20);

        JLabel label = new JLabel("Contacts:");
        label.setFont(labelFont);
        label.setBounds(100, 50, 200, 40);
        add(label);

        String[] columns = { "Name", "Contact" };
        tableModel = new DefaultTableModel(columns, 0);
        loadContactsFromFile();

        table = new JTable(tableModel);
        table.setFont(tableFont);
        table.setRowHeight(30);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 110, 800, 250);
        add(scrollPane);

        btnUpdate = new JButton("Update Contact");
        btnUpdate.setFont(buttonFont);
        btnUpdate.setBounds(100, 400, 220, 50);
        btnUpdate.addActionListener(this);
        add(btnUpdate);

        btnCreate = new JButton("Create Contact");
        btnCreate.setFont(buttonFont);
        btnCreate.setBounds(350, 400, 220, 50);
        btnCreate.addActionListener(this);
        add(btnCreate);

        btnDelete = new JButton("Delete Contact");
        btnDelete.setFont(buttonFont);
        btnDelete.setBounds(600, 400, 220, 50);
        btnDelete.addActionListener(this);
        add(btnDelete);

        setVisible(true);
    }

    private void loadContactsFromFile() {
        File file = new File("contact.txt");
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",", 2);
                    if (parts.length == 2) {
                        tableModel.addRow(new Object[] { parts[0], parts[1] });
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error reading contact file", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnUpdate) {
            dispose();
            new UpdateContact();
        } else if (e.getSource() == btnCreate) {
            dispose();
            new NewContact();
        } else if (e.getSource() == btnDelete) {
            dispose();
            new DeleteContact();
        }
    }
}
