package FullStack;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class UpdateContact extends JFrame implements ActionListener {
    JTextField firstNameField, lastNameField, phoneField;
    JButton doneButton, backButton;

    public UpdateContact() {
        setTitle("Contact Book - Update Contact");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        Font titleFont = new Font("Arial", Font.BOLD, 28);
        Font labelFont = new Font("Arial", Font.PLAIN, 22);
        Font fieldFont = new Font("Arial", Font.PLAIN, 20);
        Font buttonFont = new Font("Arial", Font.BOLD, 22);

        JLabel editLabel = new JLabel("Edit Contact");
        editLabel.setFont(titleFont);
        editLabel.setBounds(100, 50, 300, 40);
        add(editLabel);

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setFont(labelFont);
        firstNameLabel.setBounds(100, 120, 150, 30);
        add(firstNameLabel);

        firstNameField = new JTextField();
        firstNameField.setFont(fieldFont);
        firstNameField.setBounds(260, 120, 250, 30);
        add(firstNameField);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setFont(labelFont);
        lastNameLabel.setBounds(100, 170, 150, 30);
        add(lastNameLabel);

        lastNameField = new JTextField();
        lastNameField.setFont(fieldFont);
        lastNameField.setBounds(260, 170, 250, 30);
        add(lastNameField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(labelFont);
        phoneLabel.setBounds(100, 220, 150, 30);
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setFont(fieldFont);
        phoneField.setBounds(260, 220, 250, 30);
        add(phoneField);

        doneButton = new JButton("Done");
        doneButton.setFont(buttonFont);
        doneButton.setBounds(100, 280, 410, 40);
        doneButton.addActionListener(this);
        add(doneButton);

        backButton = new JButton("Back to Dashboard");
        backButton.setFont(new Font("Arial", Font.BOLD, 20));
        backButton.setBounds(100, 350, 250, 40);
        backButton.addActionListener(this);
        add(backButton);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == doneButton) {
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String phone = phoneField.getText().trim();

            if (firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
                return;
            }

            String fullName = firstName + " " + lastName;
            File originalFile = new File("contact.txt");
            File tempFile = new File("temp.txt");

            boolean found = false;

            try (
                BufferedReader reader = new BufferedReader(new FileReader(originalFile));
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))
            ) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith(fullName + ",")) {
                        writer.write(fullName + "," + phone);
                        writer.newLine();
                        found = true;
                    } else {
                        writer.write(line);
                        writer.newLine();
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error updating contact.");
                return;
            }

            if (!found) {
                tempFile.delete();
                JOptionPane.showMessageDialog(this, "Contact not found.");
                return;
            }

            if (originalFile.delete()) {
                if (tempFile.renameTo(originalFile)) {
                    JOptionPane.showMessageDialog(this, "Contact updated successfully.");
                } else {
                    JOptionPane.showMessageDialog(this, "Error renaming temp file.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Error deleting original file.");
            }

        } else if (e.getSource() == backButton) {
            dispose();
            new DashboardMain();
        }
    }
}
